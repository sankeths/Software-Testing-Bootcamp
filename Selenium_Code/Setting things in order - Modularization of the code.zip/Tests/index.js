const {Builder, Browser, By} = require('selenium-webdriver');
//const assert = require('assert')
var {login, sanityCheckPageLoad, sanityCheckInvalidLogin} = require('./functions')


var tc001 = async function(){
    let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
    try {
        //Login function - pass driver
        console.log("TC001 entry")
        await login(driver, "student@qacurry.com", "Q@curry");
        await sanityCheckPageLoad(driver, "Hello Student")
    } catch (error) {
        console.log(error);
    } finally {
        driver.quit();
        console.log("TC001 exit")
    }
}

//tc001();

var tc002 = async function(){
    let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
    try {
        console.log("TC002 entry")
        await login(driver,"not-a-student@qacurry.com","not a password")
        await sanityCheckInvalidLogin(driver,"Your Login Name or Password is invalid")
    } catch (error) {
        console.log("error")
    } finally{
    driver.quit();
    console.log("TC002 exit")
    }
}

//tc002();

var testsuite = async function(){
    await tc001();
    await tc002();
}();