const { Builder, Browser, By } = require("selenium-webdriver")
const { describe } = require("mocha")
const should = require("chai").should()
var {login, sanityCheckPageLoad, sanityCheckInvalidLogin, readData, takeScreenshot} = require('../functions');
var moreDetails = require('mochawesome/addContext')
const { assert } = require("chai");


describe("Final TestSuite",async function(){
    it("TC007", async function(){
        let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
        tcData = await readData("tc007") 
        
        try {

        //Login to the app with TC007 - username & password
        await login(driver, tcData.data.username,tcData.data.password )

        //Verify with screenshot
        var filename = await takeScreenshot(driver)
        moreDetails(this, '../'+filename) 
        
        //Add comprehensive testing book to cart
        await driver.findElement(By.id(tcData.data.bookToBuy)).click()

        //validate the book name
        var actualBook = await driver.findElement(By.xpath("//td[normalize-space()='"+tcData.data.expectedBook+"']")).getText()
        var expectedBook = tcData.data.expectedBook
        expectedBook.should.equal(actualBook)

        //Verify with screenshot
        var filename = await takeScreenshot(driver)
        moreDetails(this, '../'+filename)

        //Checkout the book
        await driver.findElement(By.name("Submit")).click()

        //Pay Offline
        await driver.findElement(By.id("offlinePay")).click()

       //verify that order has been placed
       var orderText = await driver.findElement(By.xpath("//p[normalize-space()='Your order has submitted successfully.']")).getText()
       var outputText = tcData.data.expectedOrderText
       outputText.should.equal(orderText)

       //Verify with screenshot
       var filename = await takeScreenshot(driver)
       moreDetails(this, '../'+filename)
          
        } catch (error) {
            assert.throws(error, "error here")
            console.log(error)
        } finally{
            driver.quit()
        }
    })
})