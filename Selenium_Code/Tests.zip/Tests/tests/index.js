const {Builder, Browser, By} = require('selenium-webdriver');
//const assert = require('assert')
var {login, sanityCheckPageLoad, sanityCheckInvalidLogin, readData, takeScreenshot} = require('../functions');
const { describe, beforeEach, afterEach } = require('mocha');
var moreDetails = require('mochawesome/addContext')
var fs = require('fs')

describe("Functional Test", async function(){
    beforeEach(function(){
        console.log("This is before each test - Functional Test SUite");
    })

    afterEach(function(){
        console.log("End of Test  - Functional Test SUite")
    })


    it("Tc001 - Allow a valid user to login to BookStore", async function(){
        let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
        tcData = await readData("tc001")   
    
        try {
            //Login function - pass driver
            console.log("TC001 entry")

            await login(driver, tcData.data.username, tcData.data.password);
            // First Screenshot
            var filename = await takeScreenshot(driver)
            moreDetails(this, '../'+filename)
            //
            await sanityCheckPageLoad(driver, tcData.data.expectedText)
            //moreDetails(this, "This is where our evidence will go")
            // Second Screenshot
            filename = await takeScreenshot(driver)
            moreDetails(this, '../'+filename)
            //
        } catch (error) {
            console.log(error);
        } finally {
            driver.quit();
            console.log("TC001 exit")
        }
    })

   
})


// var tc001 = async function(){
   
// }

//tc001();

// var tc002 = async function(){
   
// }

//tc002();

// var testsuite = async function(){
//     await tc001();
//     await tc002();
// }();