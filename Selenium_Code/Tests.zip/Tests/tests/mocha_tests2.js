const assert = require("assert")
const { describe } = require("mocha")

describe('TestSuite2', function(){
    it('Testcase2', function(){
        assert.equal("1","1","One is equal to One")
    })
})