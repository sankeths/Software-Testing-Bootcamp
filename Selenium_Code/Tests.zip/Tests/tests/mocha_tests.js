const assert = require("assert")
const { describe, beforeEach, afterEach } = require("mocha")

describe('TestSuite', function(){
    beforeEach(function(){
        console.log("Before each Testcase")
    })

    it('Testcase1', function(){
        assert.equal("2","1","Two is not equal to One")
    })

    afterEach(function(){
        console.log("After each Test")
    })
})