const {Builder, Browser, By} = require('selenium-webdriver');
//const assert = require('assert')
var {login, sanityCheckPageLoad, sanityCheckInvalidLogin, readData, takeScreenshot} = require('../functions');
const { describe, beforeEach, afterEach } = require('mocha');
var moreDetails = require('mochawesome/addContext')
var fs = require('fs')


describe("Regression Test", async function(){
    beforeEach(function(){
        console.log("This is before each test - Regression Test SUite");
    })

    afterEach(function(){
        console.log("End of Test  - Regression Test SUite")
    })

    it("TC002 - Should not allow login for an invalid password", async function(){
        let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
        tcData = await readData("tc002")
    
        try {
            console.log("TC002 entry")
            await login(driver,tcData.data.username, tcData.data.password)
            // First Screenshot
            var filename = await takeScreenshot(driver)
            moreDetails(this, '../'+filename)
            //            
            await sanityCheckInvalidLogin(driver,tcData.data.expectedText)
            // First Screenshot
            filename = await takeScreenshot(driver)
            moreDetails(this, '../'+filename)
            //            
        } catch (error) {
            console.log("error")
        } finally{
        driver.quit();
        console.log("TC002 exit")
        }
    })
})


// var tc001 = async function(){
   
// }

//tc001();

// var tc002 = async function(){
   
// }

//tc002();

// var testsuite = async function(){
//     await tc001();
//     await tc002();
// }();