const selenium = require("selenium-webdriver")
//const {Builder, Browser, By, Key, until} = require('selenium-webdriver');


//Function myFirstTest
myFirstTest = async function(){
    //await console.log("hello")
    let driver = await new selenium.Builder().forBrowser(selenium.Browser.FIREFOX).build();
    //let driver = await new Builder().forBrowser(Browser.FIREFOX).build();

    await driver.get("https://bookstore.qacurry.com")
    driver.quit()
    console.log("Our test was run....")
}

myFirstTest();