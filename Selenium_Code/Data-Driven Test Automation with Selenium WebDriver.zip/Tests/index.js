const {Builder, Browser, By} = require('selenium-webdriver');
//const assert = require('assert')
var {login, sanityCheckPageLoad, sanityCheckInvalidLogin, readData} = require('./functions')


var tc001 = async function(){
    let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
    tcData = await readData("tc001")


    try {
        //Login function - pass driver
        console.log("TC001 entry")
        await login(driver, tcData.data.username, tcData.data.password);
        await sanityCheckPageLoad(driver, tcData.data.expectedText)
    } catch (error) {
        console.log(error);
    } finally {
        driver.quit();
        console.log("TC001 exit")
    }
}

//tc001();

var tc002 = async function(){
    let driver = await new Builder().forBrowser(Browser.FIREFOX).build();
    tcData = await readData("tc002")

    try {
        console.log("TC002 entry")
        await login(driver,tcData.data.username, tcData.data.password)
        await sanityCheckInvalidLogin(driver,tcData.data.expectedText)
    } catch (error) {
        console.log("error")
    } finally{
    driver.quit();
    console.log("TC002 exit")
    }
}

//tc002();

var testsuite = async function(){
    await tc001();
    await tc002();
}();