const {Builder, Browser, By} = require('selenium-webdriver');
const assert = require('assert')

var tc001 = async function(){
    let driver = await new Builder().forBrowser(Browser.FIREFOX).build();

    try {
        // 1. Navigate to the login page.
        await driver.get("https://bookstore.qacurry.com");
        // 2. Enter valid username and password.
        await driver.findElement(By.xpath("//input[@name='login_email']")).sendKeys("student@qacurry.com");
        await driver.findElement(By.xpath("//input[@name='login_password']")).sendKeys("Q@curry");
        //3.  Click on the login button.
        await driver.findElement(By.xpath("//input[@value='Login']")).click()
        // Verify the text - Hello Student
        var actualText = await driver.findElement(By.xpath("//h2[contains(text(),'Hello')]")).getText()
        var expectedText = "Hello Student";
        assert.equal(actualText,expectedText,"Validation for Login")
        //console.log("TC001 navigation complete")

    } catch (error) {
        console.log(error);
    } finally {
        driver.quit();
        //
        console.log("#############")
        console.log("TC001 exit")
        console.log("#############")
    }
}

tc001();