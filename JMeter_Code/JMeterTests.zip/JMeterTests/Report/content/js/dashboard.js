/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.890625, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5833333333333334, 500, 1500, "PayOfflinePayOrder/cartAction.php-28"], "isController": false}, {"data": [0.4166666666666667, 500, 1500, "Navigate/login.php"], "isController": false}, {"data": [1.0, 500, 1500, "Login/login.php-1"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "Login/login.php-0"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "BuyABook/cartAction.php-24"], "isController": false}, {"data": [1.0, 500, 1500, "BuyABook/viewCart.php-25"], "isController": false}, {"data": [1.0, 500, 1500, "Login/welcome.php-11"], "isController": false}, {"data": [1.0, 500, 1500, "PayOfflinePayOrder/cartAction.php-28-0"], "isController": false}, {"data": [1.0, 500, 1500, "GoBackHome/welcome.php-30"], "isController": false}, {"data": [1.0, 500, 1500, "PayOfflinePayOrder/cartAction.php-28-1"], "isController": false}, {"data": [1.0, 500, 1500, "Checkout/checkout.php-26"], "isController": false}, {"data": [1.0, 500, 1500, "BuyABook/cartAction.php-24-0"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [1.0, 500, 1500, "PayOfflinePayOrder/orderSuccess.php-29"], "isController": false}, {"data": [0.5, 500, 1500, "Login/login.php"], "isController": false}, {"data": [1.0, 500, 1500, "BuyABook/cartAction.php-24-1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 96, 0, 0.0, 343.3125, 0, 1722, 251.5, 546.7999999999998, 761.1499999999983, 1722.0, 12.811957827305486, 22.13563388329107, 8.430524739757105], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["PayOfflinePayOrder/cartAction.php-28", 6, 0, 0.0, 508.3333333333333, 495, 528, 506.0, 528.0, 528.0, 528.0, 1.7452006980802792, 3.094436263816172, 1.9991410340314135], "isController": false}, {"data": ["Navigate/login.php", 6, 0, 0.0, 941.0, 712, 1722, 725.5, 1722.0, 1722.0, 1722.0, 1.2709171785638638, 1.6544263662359668, 0.5734020864223681], "isController": false}, {"data": ["Login/login.php-1", 6, 0, 0.0, 249.5, 241, 262, 248.5, 262.0, 262.0, 262.0, 1.8570102135561746, 4.21998317084494, 1.1878336815227484], "isController": false}, {"data": ["Login/login.php-0", 6, 0, 0.0, 380.3333333333333, 257, 932, 275.5, 932.0, 932.0, 932.0, 1.8359853121175032, 2.2896027769277847, 1.3124426254589965], "isController": false}, {"data": ["BuyABook/cartAction.php-24", 6, 0, 0.0, 509.8333333333333, 475, 586, 499.0, 586.0, 586.0, 586.0, 1.7201834862385321, 3.927528311353211, 1.9553648222477065], "isController": false}, {"data": ["BuyABook/viewCart.php-25", 6, 0, 0.0, 249.16666666666666, 239, 265, 248.5, 265.0, 265.0, 265.0, 1.8570102135561746, 3.5671280176415974, 1.0336873259052926], "isController": false}, {"data": ["Login/welcome.php-11", 6, 0, 0.0, 253.66666666666666, 241, 282, 249.5, 282.0, 282.0, 282.0, 1.8404907975460123, 4.182443443251534, 1.0190998849693251], "isController": false}, {"data": ["PayOfflinePayOrder/cartAction.php-28-0", 6, 0, 0.0, 260.8333333333333, 245, 274, 260.5, 274.0, 274.0, 274.0, 1.8820577164366374, 0.7020957496863237, 1.0862266703262233], "isController": false}, {"data": ["GoBackHome/welcome.php-30", 6, 0, 0.0, 246.83333333333334, 239, 260, 246.0, 260.0, 260.0, 260.0, 1.8963337547408343, 4.309344382111251, 1.0759471792035398], "isController": false}, {"data": ["PayOfflinePayOrder/cartAction.php-28-1", 6, 0, 0.0, 247.16666666666666, 241, 254, 247.5, 254.0, 254.0, 254.0, 1.8838304552590266, 2.637485282574568, 1.070692700156986], "isController": false}, {"data": ["Checkout/checkout.php-26", 6, 0, 0.0, 262.33333333333337, 245, 308, 250.5, 308.0, 308.0, 308.0, 1.846153846153846, 5.478064903846154, 1.0294471153846154], "isController": false}, {"data": ["BuyABook/cartAction.php-24-0", 6, 0, 0.0, 248.5, 238, 255, 250.5, 255.0, 255.0, 255.0, 1.8455859735466011, 0.6686644494001845, 1.070584051061212], "isController": false}, {"data": ["Debug Sampler", 6, 0, 0.0, 0.8333333333333334, 0, 2, 1.0, 2.0, 2.0, 2.0, 2.0682523267838677, 0.7385653653912444, 0.0], "isController": false}, {"data": ["PayOfflinePayOrder/orderSuccess.php-29", 6, 0, 0.0, 243.0, 237, 250, 243.0, 250.0, 250.0, 250.0, 1.889168765743073, 2.6449592647984885, 1.0737267789672544], "isController": false}, {"data": ["Login/login.php", 6, 0, 0.0, 630.5, 510, 1180, 522.5, 1180.0, 1180.0, 1180.0, 1.7098888572242803, 6.018007267027643, 2.316031098603591], "isController": false}, {"data": ["BuyABook/cartAction.php-24-1", 6, 0, 0.0, 261.1666666666667, 237, 335, 248.5, 335.0, 335.0, 335.0, 1.8529956763434219, 3.5594164993823347, 1.0314526714021002], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 96, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
